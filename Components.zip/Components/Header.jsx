import React from 'react'

function Header() {
  return (
    <div>
      <h1 style={{letterSpacing: "2px"}}>SOFTWARE DEVELOPER</h1>
    </div>
  )
}

export default Header
