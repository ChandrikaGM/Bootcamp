import React from 'react'
import About from './About';
import Header from './Header';
import Carousel_element from './Carousel_element';


function Home() {
  return (
    <div>
      <Header/>
      <About/>
{/* <Carousel_element/> */}
    </div>
  )
}

export default Home
