import React from 'react'
import { useState } from 'react';
import Carousel_element from './Carousel_element';
function Counter() {
  const[count,setcount]=useState(0);  
  const[ncount,setNcount]=useState(count)
  
  const handleIncrement =()=>{
    setcount(count+1);}

//   let ncount=count;
  const decrement=() =>{
    setNcount(ncount-1);
  }

  return (
    <div>
        <Carousel_element/>
      <button onClick={handleIncrement}>Click here</button>
      <h1>{count}</h1>
      <button onClick={decrement}> Decrement</button>
      <h1>{ncount}</h1>
    </div>
  )
}





export default Counter

