import React from 'react'

function Multiple() {
    const Tablem=() =>{
    const count=1;
    for(let i=1;i<=10;i++)
        { let temp=count*i
           
            console.log(temp );}}
  return (
    <div>
      <button onClick={Tablem}></button>
    </div>
  )
}

export default Multiple
