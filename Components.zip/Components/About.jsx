import React from 'react'
import Image1 from './image1.png';
import './About.css'
// import Navbar from './Navbar.jsx';
function About() {
  return (
  <>
      <img src={Image1} className='image' />
      <p>Lorem ipsum dolor, sit amet consectetur adipisicing elit. Iure provident numquam error sit, tempore vel.</p>
      <p>Lorem ipsum dolor, sit amet consectetur adipisicing elit. Iure provident numquam error sit, tempore vel.</p>
      <p>Lorem ipsum dolor, sit amet consectetur adipisicing elit. Iure provident numquam error sit, tempore vel.</p>
      <p>Lorem ipsum dolor, sit amet consectetur adipisicing elit. Iure provident numquam error sit, tempore vel.</p>
      </>
  )
}

export default About
